package com.example.urlhud;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Native-side local bookmark persistence (SharedPreferences-backed).
 * Not currently wired up: bookmarks are persisted on the JS side via
 * localStorage in app.js (see saveBookmarks()/loadBookmarks() there).
 * This store is kept around for a future native bridge if one is added.
 *
 * Same single-value-in-SharedPreferences pattern as SessionStore/DownloadsStore.
 */
public class BookmarkStore {

    private static final String PREFS_NAME = "urlhud_bookmarks";
    private static final String KEY_BOOKMARKS = "bookmarks_json";

    private final SharedPreferences prefs;

    public BookmarkStore(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String load() {
        return prefs.getString(KEY_BOOKMARKS, "[]");
    }

    public void save(String bookmarksJson) {
        prefs.edit().putString(KEY_BOOKMARKS, bookmarksJson).apply();
    }
}
